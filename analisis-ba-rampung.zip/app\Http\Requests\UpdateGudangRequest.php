<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateGudangRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()
            && $this->user()->role === 'admin_kantor';
    }

    public function rules(): array
    {
        return [
            'kode_gudang' => [
                'required',
                'string',
                'max:20',
                'unique:gudangs,kode_gudang,' . $this->route('gudang')->id,
            ],

            'nama_gudang' => [
                'required',
                'string',
                'max:150',
            ],

            'alamat' => [
                'nullable',
                'string',
                'max:500',
            ],

            'kecamatan' => [
                'nullable',
                'string',
                'max:100',
            ],

            'desa' => [
                'nullable',
                'string',
                'max:100',
            ],

            'nomor_telepon' => [
                'nullable',
                'string',
                'max:30',
            ],

            'email' => [
                'nullable',
                'email',
                'max:150',
            ],

            'kapasitas' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'luas_m2' => ['nullable', 'numeric', 'min:0'],
            'panjang_m' => ['nullable', 'numeric', 'min:0'],
            'lebar_m' => ['nullable', 'numeric', 'min:0'],
            'tinggi_m' => ['nullable', 'numeric', 'min:0'],

            'status' => [
    'required',
    'in:aktif,nonaktif',
],

'gudang_induk_id' => [
    'nullable',
    'exists:gudangs,id',
],
        ];
    }

    public function messages(): array
    {
        return [
            'kode_gudang.required' => 'Kode Gudang wajib diisi.',
            'kode_gudang.unique' => 'Kode Gudang sudah digunakan, gunakan kode lain.',

            'nama_gudang.required' => 'Nama Gudang wajib diisi.',

            'email.email' => 'Format email tidak valid.',

            'kapasitas.numeric' => 'Kapasitas harus berupa angka.',
            'kapasitas.min' => 'Kapasitas tidak boleh negatif.',
            'luas_m2.numeric' => 'Luas gudang harus berupa angka.',
            'luas_m2.min' => 'Luas gudang tidak boleh negatif.',
            'panjang_m.numeric' => 'Panjang gudang harus berupa angka.',
            'panjang_m.min' => 'Panjang gudang tidak boleh negatif.',
            'lebar_m.numeric' => 'Lebar gudang harus berupa angka.',
            'lebar_m.min' => 'Lebar gudang tidak boleh negatif.',
            'tinggi_m.numeric' => 'Tinggi gudang harus berupa angka.',
            'tinggi_m.min' => 'Tinggi gudang tidak boleh negatif.',

            'status.required' => 'Status wajib dipilih.',
        ];
    }
}