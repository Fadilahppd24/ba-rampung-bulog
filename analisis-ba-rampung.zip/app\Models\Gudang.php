<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Gudang extends Model
{
    use HasFactory;

    protected $fillable = [
    'kode_gudang',
    'nama_gudang',
    'alamat',
    'kecamatan',
    'desa',
    'nomor_telepon',
    'email',
    'kapasitas',
    'luas_m2',
    'panjang_m',
    'lebar_m',
    'tinggi_m',
    'status',
    'gudang_induk_id',
];

    protected function casts(): array
    {
        return [
            'kapasitas' => 'decimal:2',
            'luas_m2' => 'decimal:2',
            'panjang_m' => 'decimal:2',
            'lebar_m' => 'decimal:2',
            'tinggi_m' => 'decimal:2',
        ];
    }

    public function baRampungs(): HasMany
    {
        return $this->hasMany(BaRampung::class);
    }

    public function gudangInduk()
{
    return $this->belongsTo(Gudang::class, 'gudang_induk_id');
}

public function gudangFilial(): HasMany
{
    return $this->hasMany(Gudang::class, 'gudang_induk_id');
}

    public function scopeAktif($query)
    {
        return $query->where('status', 'aktif');
    }
}
